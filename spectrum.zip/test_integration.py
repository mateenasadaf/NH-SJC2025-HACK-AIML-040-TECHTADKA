from fusion_model import unified_prediction



# --- Case 2: Only Transaction Input ---
transaction_features = [181, 1, 0, 9830, 170136.0, 160296.36, 0.0, 0.0]
unified_prediction(transaction_features=transaction_features)

# --- Case 3: Both (optional) ---
